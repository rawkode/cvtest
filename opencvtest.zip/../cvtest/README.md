```
$ go run main.go

# gocv.io/x/gocv
In file included from features2d.cpp:1:
../../go/pkg/mod/gocv.io/x/gocv@v0.25.0/features2d.h:23:21: error: no member named 'SIFT' in namespace 'cv'
features2d.cpp:478:28: error: no member named 'SIFT' in namespace 'cv'
features2d.cpp:487:11: error: member reference type 'int' is not a pointer
features2d.cpp:504:11: error: member reference type 'int' is not a pointer
```
